class AddressData{
   double lat;
   double longi;
   String address1;
   String address2;
   String shopNumber;
   String landMark;

  AddressData(
      {this.lat,
      this.longi,
      this.address1,
      this.address2,
      this.shopNumber,
      this.landMark});

}