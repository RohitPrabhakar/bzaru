class IntroModel {
  final String title;
  final String subTitle;
  final String imagePath;

  IntroModel({
    this.title,
    this.subTitle,
    this.imagePath,
  });
}
