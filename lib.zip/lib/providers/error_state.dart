import 'package:flutter/material.dart';

class ErrorState extends ChangeNotifier {}
