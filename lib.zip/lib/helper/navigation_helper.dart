import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bzaru/helper/utility.dart';
import 'package:flutter_bzaru/ui/pages/common/common_pages.dart';

class BNavigation {
  BNavigation._();

  // static void pushNavigate(
  //     BuildContext context, CupertinoPageRoute pageRoute) async {
  //   final bool isInternetAvaliable = await Utility.hasInternetConnection();

  //   if (isInternetAvaliable) {
  //     Navigator.of(context).push(pageRoute);
  //   } else {
  //     Navigator.of(context)
  //         .push(CupertinoPageRoute(builder: (context) => NoInternet()));
  //   }
  // }

  // static void pushReplaceNavigate(
  //     BuildContext context, CupertinoPageRoute pageRoute) async {
  //   final bool isInternetAvaliable = await Utility.hasInternetConnection();

  //   if (isInternetAvaliable) {
  //     Navigator.of(context).pushReplacement(pageRoute);
  //   } else {
  //     Navigator.of(context)
  //         .push(CupertinoPageRoute(builder: (context) => NoInternet()));
  //   }
  // }

  // static void popNavigate(BuildContext context) async {
  //   final bool isInternetAvaliable = await Utility.hasInternetConnection();

  //   if (isInternetAvaliable) {
  //     Navigator.of(context).pop();
  //   } else {
  //     Navigator.of(context)
  //         .push(CupertinoPageRoute(builder: (context) => NoInternet()));
  //   }
  // }
}
